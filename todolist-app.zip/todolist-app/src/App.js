import React from "react";
import Todo from "./components/todo";
import "./components/todo.css";

const App = () => {
  return (
    <>
      <Todo />
    </>
  );
};

export default App;
